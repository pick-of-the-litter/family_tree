# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['family_tree', 'family_tree.tests']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'family-tree',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Ash Murphy',
    'author_email': 'amurphy9956@live.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
